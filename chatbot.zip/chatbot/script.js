let stage = 0;
let order = {
  pasta: "",
  sauce: "",
  addins: "",
  sides: ""
};

function addMessage(text, className) {
  const chatbox = document.getElementById("chatbox");
  const msg = document.createElement("div");
  msg.className = className;
  msg.innerHTML = text;
  chatbox.appendChild(msg);
  chatbox.scrollTop = chatbox.scrollHeight;
}

function processInput() {
  const input = document.getElementById("userInput");
  const userText = input.value.trim();
  if (userText === "") return;

  addMessage(userText, "user-msg");
  input.value = "";

  switch (stage) {
    case 0:
      order.pasta = userText;
      addMessage("Great! Now choose your sauce: (Marinara, Alfredo, Pesto, Carbonara)", "bot-msg");
      stage = 1;
      break;
    case 1:
      order.sauce = userText;
      addMessage("Nice! Any add-ins? (Chicken, Shrimp, Meatballs, Mushrooms, Broccoli)", "bot-msg");
      stage = 2;
      break;
    case 2:
      order.addins = userText;
      addMessage("Want sides? (Garlic Bread, Salad)", "bot-msg");
      stage = 3;
      break;
    case 3:
      order.sides = userText;
      addMessage(`Here’s your order summary:\n Pasta: ${capitalize(order.pasta)}\n Sauce: ${capitalize(order.sauce)}\n➕ Add-ins: ${capitalize(order.addins)}\n Sides: ${capitalize(order.sides)}\nWould you like to confirm? (yes/no)`, "bot-msg");
      stage = 4;
      break;
    case 4:
      if (userText.toLowerCase() === "yes") {
        addMessage("Thank you! Your order is being processed. 🧾", "bot-msg");
        stage = 5;
      } else {
        addMessage("Order canceled. Restarting...", "bot-msg");
        stage = 0;
        order = { pasta: "", sauce: "", addins: "", sides: "" };
        addMessage("What type of pasta would you like? ( Penne, Fusilli, Spaghetti)", "bot-msg");
      }
      break;
    default:
      addMessage("Conversation ended. Refresh to start a new order.", "bot-msg");
      break;
  }
}

function capitalize(text) {
  return text
    .split(",")
    .map(word => word.trim().charAt(0).toUpperCase() + word.trim().slice(1))
    .join(", ");
}

window.onload = function () {
  addMessage("🍝 Pasta Bot\nHello! I'm <b>Pasta Bot</b>. Let's customize your pasta order!\nWhat type of pasta would you like? (e.g., Penne, Fusilli, Spaghetti)", "bot-msg");
};
