import re

class PastaBot:
    def __init__(self):
        self.pasta_type = None
        self.sauce = None
        self.addins = []
        self.sides = []
        
    def normalize_input(self, user_input):
        """ Normalize user input to lower case and remove leading/trailing spaces """
        return user_input.strip().lower()
    
    def greet_user(self):
        print("Bot: Hello! I'm Pasta Bot. I can help you customize your pasta order.")
        
    def ask_pasta_type(self):
        pasta_options = ["spaghetti", "penne", "fusilli", "linguine"]
        print("Bot: What type of pasta would you like? We have: Spaghetti, Penne, Fusilli, Linguine.")
        user_input = self.normalize_input(input("You: "))
        
        while user_input not in pasta_options:
            print("Bot: Sorry, I didn't understand that. Please choose a valid pasta type.")
            user_input = self.normalize_input(input("You: "))
        
        self.pasta_type = user_input
        print(f"Bot: Great! You chose {self.pasta_type.capitalize()} pasta.")
        
    def ask_sauce(self):
        sauce_options = ["marinara", "alfredo", "pesto", "carbonara"]
        print("Bot: What sauce would you like? We have: Marinara, Alfredo, Pesto, Carbonara.")
        user_input = self.normalize_input(input("You: "))
        
        while user_input not in sauce_options:
            print("Bot: Sorry, I didn't understand that. Please choose a valid sauce.")
            user_input = self.normalize_input(input("You: "))
        
        self.sauce = user_input
        print(f"Bot: Nice choice! You selected {self.sauce.capitalize()} sauce.")
        
    def ask_addins(self):
        addin_options = ["chicken", "shrimp", "meatballs", "mushrooms", "broccoli"]
        print("Bot: What add-ins would you like to include? Available options: Chicken, Shrimp, Meatballs, Mushrooms, Broccoli.")
        user_input = self.normalize_input(input("You: "))
        
        # Split user input into items and check each one
        addin_choices = [item.strip() for item in user_input.split(",")]
        for addin in addin_choices:
            if addin in addin_options and addin not in self.addins:
                self.addins.append(addin)
        
        if self.addins:
            print(f"Bot: You've added: {', '.join([item.capitalize() for item in self.addins])}.")
        else:
            print("Bot: You didn't add any extra items.")
        
    def ask_sides(self):
        print("Bot: Would you like any sides with your pasta? You can choose from: Garlic Bread, Salad.")
        user_input = self.normalize_input(input("You: "))
        
        # Simple logic for sides: check if they are in the available options
        if "garlic bread" in user_input:
            self.sides.append("garlic bread")
        if "salad" in user_input:
            self.sides.append("salad")
        
        if self.sides:
            print(f"Bot: You've selected the following sides: {', '.join([item.capitalize() for item in self.sides])}.")
        else:
            print("Bot: No sides selected.")
        
    def confirm_order(self):
        print("\nBot: Here's your order summary:")
        print(f"Bot: Pasta Type: {self.pasta_type.capitalize()}")
        print(f"Bot: Sauce: {self.sauce.capitalize()}")
        
        if self.addins:
            print(f"Bot: Add-ins: {', '.join([item.capitalize() for item in self.addins])}")
        else:
            print("Bot: Add-ins: None")
        
        if self.sides:
            print(f"Bot: Sides: {', '.join([item.capitalize() for item in self.sides])}")
        else:
            print("Bot: Sides: None")
        
        print("\nBot: Would you like to confirm this order? (yes/no)")
        user_input = self.normalize_input(input("You: "))
        
        if user_input == "yes":
            print("Bot: Thank you! Your order has been placed.")
        else:
            print("Bot: No problem! Feel free to start over whenever you're ready.")
        
    def run(self):
        self.greet_user()
        self.ask_pasta_type()
        self.ask_sauce()
        self.ask_addins()
        self.ask_sides()
        self.confirm_order()


# Run the PastaBot
if __name__ == "__main__":
    bot = PastaBot()
    bot.run()
